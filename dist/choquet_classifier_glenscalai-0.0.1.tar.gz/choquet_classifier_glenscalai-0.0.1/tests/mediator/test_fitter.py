import unittest
import numpy as np

from classifier.mediator.fitter import Fitter


class TestFitter(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()
